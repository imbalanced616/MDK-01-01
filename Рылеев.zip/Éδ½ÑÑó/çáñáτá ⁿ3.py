# Толковый словарь

while True:
    N = int(input('Введите количество записей: '))
    if 1 <= N <= 1000:
        break
    print('Внимание! 1≤N≤1000 !')
print('Введите слово, а затем через пробел непустое описание его значения ' + str(N) + ' раз(а):')
dictionary = {k[0]: ' '.join(k[1:]) for k in [input(str(i + 1) + '. ').split() for i in range(N)]}
print()
while True:
    M = int(input('Введите количество проверяемых записей: '))
    if 1 <= M <= 100:
        break
    print('1≤M≤100 !')
print('Введите слова для проверки ' + str(M) + ' раз(а):')
words = [input(str(i + 1) + '. ') for i in range(M)]
print()
[print(i + ' — ' + dictionary.setdefault(i, 'Нет в словаре')) for i in words]
